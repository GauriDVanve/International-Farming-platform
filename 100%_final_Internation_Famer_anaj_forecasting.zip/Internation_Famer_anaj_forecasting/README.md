# Apna Anaaj (Flask + SQLite)

This project shows commodity price trend insights and simple month-wise forecasts.

## Features added

- Home / About / Contact pages
- Login + Registration (SQLite)
- Contact form saved to SQLite
- Modern Bootstrap 5 UI (glassmorphism style)

## Run (Windows / Linux)

```bash
python -m venv .venv
source .venv/bin/activate   # (Windows: .venv\\Scripts\\activate)

pip install -r requirements.txt

python app.py
```

Open: `http://127.0.0.1:5000/`

> The database file `apna_anaaj.sqlite3` is auto-created on first run.


## Fix for: `ValueError: numpy.dtype size changed`

This happens due to NumPy / scikit-learn binary mismatch. Reinstall matching versions:

```bash
# If using conda (recommended)
conda install -c conda-forge --force-reinstall numpy=1.26.4 scikit-learn=1.4.2 scipy=1.11.4 joblib=1.3.2 -y

# Or pip
pip install --upgrade --force-reinstall --no-cache-dir numpy==1.26.4 scikit-learn==1.4.2 scipy==1.11.4 joblib==1.3.2
```
